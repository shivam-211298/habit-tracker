# GitHub PWA with IndexedDB

This project is a Progressive Web App (PWA) that integrates with the GitHub API and utilizes IndexedDB for data storage. It allows users to interact with GitHub data while providing offline capabilities through service workers.

## Features

- **Progressive Web App**: Installable on devices, works offline, and provides a native app-like experience.
- **GitHub Integration**: Fetch user data and repositories from GitHub.
- **IndexedDB Storage**: Store and manage data locally in the browser using IndexedDB.
- **Responsive Design**: Works seamlessly across different devices and screen sizes.

## Project Structure

```
github-pwa-indexeddb-project
├── public
│   ├── index.html          # Main HTML document
│   ├── manifest.json       # PWA metadata
│   └── service-worker.js    # Service worker for caching
├── src
│   ├── app.js              # Main application logic
│   ├── db
│   │   └── indexeddb.js    # IndexedDB interactions
│   ├── github
│   │   └── api.js          # GitHub API interactions
│   ├── styles
│   │   └── styles.css       # Application styles
│   └── utils
│       └── helpers.js      # Utility functions
├── package.json            # npm configuration
├── webpack.config.js       # Webpack configuration
└── README.md               # Project documentation
```

## Setup Instructions

1. **Clone the repository**:
   ```
   git clone https://github.com/yourusername/github-pwa-indexeddb-project.git
   cd github-pwa-indexeddb-project
   ```

2. **Install dependencies**:
   ```
   npm install
   ```

3. **Build the project**:
   ```
   npm run build
   ```

4. **Start the development server**:
   ```
   npm start
   ```

5. **Open the application**:
   Navigate to `http://localhost:3000` in your web browser.

## Usage

- Use the application to log in with your GitHub account and access your repositories.
- The application will cache data for offline use, allowing you to view previously fetched data without an internet connection.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.