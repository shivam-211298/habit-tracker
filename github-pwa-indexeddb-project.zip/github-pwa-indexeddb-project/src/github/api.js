const GITHUB_API_URL = 'https://api.github.com';

export async function fetchUserData(username) {
    try {
        const response = await fetch(`${GITHUB_API_URL}/users/${username}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching user data:', error);
        throw error;
    }
}

export async function fetchUserRepos(username) {
    try {
        const response = await fetch(`${GITHUB_API_URL}/users/${username}/repos`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching user repositories:', error);
        throw error;
    }
}

export async function authenticateUser(token) {
    try {
        const response = await fetch(`${GITHUB_API_URL}/user`, {
            headers: {
                Authorization: `token ${token}`
            }
        });
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error('Error authenticating user:', error);
        throw error;
    }
}

export async function fetchGitHubData(username) {
    const response = await fetch(`${GITHUB_API_URL}/users/${username}/repos`);
    if (!response.ok) {
        throw new Error('Failed to fetch data from GitHub');
    }
    return response.json();
}