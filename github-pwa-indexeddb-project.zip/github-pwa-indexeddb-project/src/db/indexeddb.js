// This file contains functions for interacting with IndexedDB, including creating a database, adding, retrieving, and deleting records.

const DB_NAME = 'githubPWA';
const DB_VERSION = 1;
const STORE_NAME = 'data';

// Open a connection to the IndexedDB database
export function openDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: 'id' });
            }
        };

        request.onsuccess = (event) => {
            resolve(event.target.result);
        };

        request.onerror = (event) => {
            reject(event.target.error);
        };
    });
}

// Add a new habit to the database
export function saveData(data) {
    return openDB().then((db) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        store.put(data);
        return transaction.complete;
    });
}

// Retrieve all habits from the database
export function getData(id) {
    return openDB().then((db) => {
        const transaction = db.transaction(STORE_NAME, 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        return store.get(id);
    });
}

// Delete a habit from the database by ID
export function deleteHabit(id) {
    return openDB().then((db) => {
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(STORE_NAME, 'readwrite');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.delete(id);

            request.onsuccess = () => {
                resolve(id);
            };

            request.onerror = (event) => {
                reject('Delete error: ' + event.target.errorCode);
            };
        });
    });
}