// src/app.js

import { initializeDatabase, saveData, getData } from './db/indexeddb.js';
import { fetchUserData, fetchGitHubData } from './github/api.js';
import './styles/styles.css';

const app = document.getElementById('app');

document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/service-worker.js').then(() => {
        console.log('Service Worker registered successfully.');
      }).catch((error) => {
        console.error('Service Worker registration failed:', error);
      });
    }
});

function initializeApp() {
    initializeDatabase();
    setupEventListeners();
}

function setupEventListeners() {
    const fetchUserButton = document.getElementById('fetchUserButton');
    fetchUserButton.addEventListener('click', () => {
        const username = document.getElementById('usernameInput').value;
        fetchUserData(username);
    });
}

async function syncData(username) {
  try {
    const data = await fetchGitHubData(username);
    await saveData({ id: username, repos: data });
    renderData(data);
  } catch (error) {
    console.error('Error syncing data:', error);
    const cachedData = await getData(username);
    if (cachedData) {
      renderData(cachedData.repos);
    } else {
      app.textContent = 'Failed to fetch data and no cached data available.';
    }
  }
}

function renderData(repos) {
  app.innerHTML = `
    <h2>Repositories</h2>
    <ul>
      ${repos.map((repo) => `<li>${repo.name}</li>`).join('')}
    </ul>
  `;
}

// Sync data for a specific GitHub username
syncData('your-github-username');